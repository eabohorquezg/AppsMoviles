package tictactoe.unal.edu.co.tictactoe;

/**
 * Created by Edwin on 18/09/17.
 */

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class AndroidTicTacToeActivity extends AppCompatActivity {

    private TicTacToeGame mGame;

    private SharedPreferences mPrefs;

    private BoardView mBoardView;
    MediaPlayer mHumanMediaPlayer;
    MediaPlayer mComputerMediaPlayer;

    // Various text displayed
    private TextView mInfoTextView;
    private TextView mCounterTextView;
    private TextView mDifficultyTextView;

    private boolean mGameOver;
    private boolean humanTurn;

    private int humanWins = 0;
    private int androidWins = 0;
    private int ties = 0;

    //static final int DIALOG_DIFFICULTY_ID = 0;
    static final int DIALOG_QUIT_ID = 1;
    static final int DIALOG_ABOUT_ID = 2;
    static final int DIALOG_RESET_ID = 3;
    boolean mSoundOn;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == RESULT_CANCELED ) {
            // Apply potentially new settings
            mSoundOn = mPrefs.getBoolean("sound", true);
            String difficultyLevel = mPrefs.getString("difficulty_level",getResources().getString(R.string.difficulty_harder));
            if (difficultyLevel.equals(getResources().getString(R.string.difficulty_easy))) {
                mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Easy);
                mDifficultyTextView.setText("Dificultad: " + mGame.getDifficultyLevel().toString());
            }
            else if (difficultyLevel.equals(getResources().getString(R.string.difficulty_harder))) {
                mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Harder);
                mDifficultyTextView.setText("Dificultad: " + mGame.getDifficultyLevel().toString());
            }
            else{
                mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Expert);
                mDifficultyTextView.setText("Dificultad: " + mGame.getDifficultyLevel().toString());
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_android_tic_tac_toe);

        mGame = new TicTacToeGame();

        // Restore the scores from the persistent preference data source
        mPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        mSoundOn = mPrefs.getBoolean("sound", true);
        String difficultyLevel = mPrefs.getString("difficulty_level",getResources().getString(R.string.difficulty_easy));
        if (difficultyLevel.equals(getResources().getString(R.string.difficulty_easy)))
            mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Easy);
        else if (difficultyLevel.equals(getResources().getString(R.string.difficulty_harder)))
            mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Harder);
        else
            mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Expert);

        //mPrefs = getSharedPreferences("ttt_prefs", MODE_PRIVATE);
        // Restore the scores
        humanWins = mPrefs.getInt("mHumanWins", 0);
        androidWins = mPrefs.getInt("mComputerWins", 0);
        ties = mPrefs.getInt("mTies", 0);

        mInfoTextView = (TextView) findViewById(R.id.information);
        mCounterTextView = (TextView) findViewById(R.id.counter);
        mDifficultyTextView = (TextView) findViewById(R.id.difficulty);
        mBoardView = (BoardView) findViewById(R.id.board);
        mBoardView.setOnTouchListener(mTouchListener);
        mBoardView.setGame(mGame);
        humanWins = 0;
        if (savedInstanceState == null) {
            startNewGame();
        }
        else {
            mGame.setBoardState(savedInstanceState.getCharArray("board"));
            mGameOver = savedInstanceState.getBoolean("mGameOver");
            humanTurn = savedInstanceState.getBoolean("mTurn");
            displayInfo();
        }
    }

    private void startNewGame() {
        mGameOver = false;
        humanTurn = true;
        mGame.clearBoard();

        mBoardView.invalidate();
        // Human goes first
        mInfoTextView.setText(R.string.first_human);
        mCounterTextView.setText("Human: " + humanWins + " | Android: " + androidWins + " | Ties: " + ties);
        mDifficultyTextView.setText("Dificultad: " + mGame.getDifficultyLevel().toString());
    }

    private boolean setMove(char player, int location) {

        if (mGame.setMove(player, location)) {
            if( mSoundOn ) {
                if (player == mGame.HUMAN_PLAYER)
                    mHumanMediaPlayer.start();
                else
                    mComputerMediaPlayer.start();
            }
            mBoardView.invalidate();
            return true;
        }
        return false;
    }

    private void checkResult(int winner){

        if (winner == 1) {
            mInfoTextView.setText(R.string.result_tie);
            ties++;
            mGameOver = true;
        } else if (winner == 2) {
            /*
            mInfoTextView.setText(R.string.result_human_wins);
            humanWins++;
            mGameOver = true;
            */
            humanWins++;
            mInfoTextView.setText(mPrefs.getString("victory_message",""));
            mGameOver = true;
        } else if (winner == 3){
            mInfoTextView.setText(R.string.result_computer_wins);
            androidWins++;
            mGameOver = true;
        }

        if(mGameOver)
            mCounterTextView.setText("Human: " + humanWins + " | Android: " + androidWins + " | Ties: " + ties);
    }


    private void displayInfo() {
        if(humanTurn)
            mInfoTextView.setText(R.string.turn_human);
        else
            mInfoTextView.setText(R.string.turn_computer);

        mCounterTextView.setText("Human: " + humanWins + " | Android: " + androidWins + " | Ties: " + ties);
        mDifficultyTextView.setText("Dificultad: " + mGame.getDifficultyLevel().toString());
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.new_game:
                startNewGame();
                return true;
            /*
            case R.id.ai_difficulty:
                showDialog(DIALOG_DIFFICULTY_ID);
                return true;
            */
            case R.id.settings:
                startActivityForResult(new Intent(this, Settings.class), 0);
                return true;
            case R.id.quit:
                showDialog(DIALOG_QUIT_ID);
                return true;
            case R.id.about:
                showDialog(DIALOG_ABOUT_ID);
                return true;
            case R.id.reset_scores:
                showDialog(DIALOG_RESET_ID);
                return true;
        }
        return false;
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        Dialog dialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        switch(id) {
            /*
            case DIALOG_DIFFICULTY_ID:

                builder.setTitle(R.string.difficulty_choose);

                final CharSequence[] levels = {
                        getResources().getString(R.string.difficulty_easy),
                        getResources().getString(R.string.difficulty_harder),
                        getResources().getString(R.string.difficulty_expert)};

                // TODO: Set selected, an integer (0 to n-1), for the Difficulty dialog.
                // selected is the radio button that should be selected.
                final int selected;

                if(mGame.getDifficultyLevel() == TicTacToeGame.DifficultyLevel.Easy){
                    selected = 0;
                }
                else if(mGame.getDifficultyLevel() == TicTacToeGame.DifficultyLevel.Harder){
                    selected = 1;
                }
                else{
                    selected = 2;
                }

                builder.setSingleChoiceItems(levels, selected,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int item) {
                                dialog.dismiss();   // Close dialog

                                // TODO: Set the diff level of mGame based on which item was selected.
                                if(item == 0){
                                    mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Easy);
                                }
                                else if(item == 1){
                                    mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Harder);
                                }
                                else{
                                    mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Expert);
                                }

                                mDifficultyTextView.setText("Dificultad: " + mGame.getDifficultyLevel().toString());

                                // Display the selected difficulty level
                                Toast.makeText(getApplicationContext(), levels[item],
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                dialog = builder.create();

                break;
            */
            case DIALOG_QUIT_ID:
                // Create the quit confirmation dialog
                builder.setMessage(R.string.quit_question)
                        .setCancelable(false)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                AndroidTicTacToeActivity.this.finish();
                                humanWins = 0;
                                androidWins = 0;
                                ties = 0;
                            }
                        })
                        .setNegativeButton(R.string.no, null);
                dialog = builder.create();
                break;

            case DIALOG_ABOUT_ID:
                Context context = getApplicationContext();
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
                View layout = inflater.inflate(R.layout.about_dialog,null);
                builder.setView(layout);
                builder.setPositiveButton("OK", null);
                dialog = builder.create();
                break;

            case DIALOG_RESET_ID:
                humanWins = 0;
                androidWins = 0;
                ties = 0;
                displayInfo();
                break;

        }

        return dialog;
    }

    @Override
    protected void onResume() {
        super.onResume();

        mHumanMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.human);
        mComputerMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.android);
    }

    @Override
    protected void onPause() {
        super.onPause();

        mHumanMediaPlayer.release();
        mComputerMediaPlayer.release();
    }

    @Override
    protected void onStop() {
        super.onStop();
        SharedPreferences.Editor ed = mPrefs.edit();
        ed.putInt("mHumanWins", humanWins);
        ed.putInt("mComputerWins", androidWins);
        ed.putInt("mTies", ties);
        ed.putString("mDifficulty", String.valueOf(mGame.getDifficultyLevel()));
        ed.commit();
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putCharArray("board", mGame.getBoardState());
        outState.putBoolean("mGameOver", mGameOver);
        outState.putCharSequence("info", mInfoTextView.getText());
        outState.putBoolean("mTurn", humanTurn);
    }

    // Listen for touches on the board
    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {

            // Determine which cell was touched
            int col = (int) event.getX() / mBoardView.getBoardCellWidth();
            int row = (int) event.getY() / mBoardView.getBoardCellHeight();
            int pos = row * 3 + col;


            if (humanTurn && !mGameOver &&  mGame.getBoardOccupant(pos) == mGame.OPEN_SPOT && setMove(TicTacToeGame.HUMAN_PLAYER, pos))	{

                humanTurn = false;

                // If no winner yet, let the computer make a move
                int winner = mGame.checkForWinner();

                if (winner == 0) {
                    mInfoTextView.setText(R.string.turn_computer);
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        public void run() {
                            int move = mGame.getComputerMove();
                            setMove(TicTacToeGame.COMPUTER_PLAYER, move);
                            humanTurn = true;
                            mInfoTextView.setText(R.string.turn_human);
                            int winner = mGame.checkForWinner();
                            checkResult(winner);
                       }
                    }, 1000);
                }

                checkResult(winner);

            }

            // So we aren't notified of continued events when finger is moved
            return false;
        }
    };

}

